<?php 
    //Include Constants Page
    include('../config/constants.php');

    if(isset($_GET['id']) && isset($_GET['image_name']))
    {
        //delete process
        //1. get the image name
        $id = $_GET['id'];
        $image_name = $_GET['image_name'];

        //2. remove the image if available
        if($image_name != "")
        {
            //it has image and need to remove from folder
            //get the image path
            $path = "../images/food/".$image_name;

            //remove image from folder
            $remove = unlink($path);

            //check whether image exists
            if($remove==false)
            {
                //failed to remove image
                $_SESSION['upload'] = "<div class='error'>Failed to remove image file</div>";
                header('location:'.SITEURL. 'admin/manage-food.php');
                //stop the process of deleting food
                die();
            }
        }

        //3. delete food from database
        $sql = "DELETE FROM tbl_food WHERE id=$id";
        //execute the query
        $res = mysqli_query($conn, $sql);

        //check whether the query was executed or not and set the session message accordingly
        if($res==true)
        {
            //food deleted successfully
            $_SESSION['delete'] = "<div class='success'>Food Deleted Successfully</div>";
            header('location:'.SITEURL.'admin/manage-food.php');
        }

        //4. redirect to manage food page with session message
    }
    else
    {
        //redirect to manage food page
        $_SESSION['delete'] = "<div class='error'>Unauthorised Access</div>";
        header('location:'.SITEURL.'admin/manage-food.php');
    }

?>