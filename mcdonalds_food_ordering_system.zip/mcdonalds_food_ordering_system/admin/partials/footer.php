 <!-- Footer Section Starts -->
 <div class="footer">
            <div class="wrapper">
                <p class="text-center">For Education Purposes Only, Mcdonalds Food Ordering System. Developed by - <a href="https://en.wikipedia.org/wiki/Keith_Foo">Keith</a> </p>
            </div>
        </div>
        <!-- Footer Section Ends -->
    </body>
</html>