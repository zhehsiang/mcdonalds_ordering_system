    <?php 
        //Start Session
        session_start();



        //create constants to store non repeating values
        define('SITEURL', 'http://localhost/mcdonalds_food_ordering_system/');
        define('LOCALHOST', 'localhost');
        define('DB_USERNAME', 'root');
        define('DB_PASSWORD', '');
        define('DB_NAME', 'mcdonalds_ordering_system');

        $conn = mysqli_connect(LOCALHOST, DB_USERNAME, DB_PASSWORD) or die(mysqli_error()); //database connection
        $db_select = mysqli_select_db($conn, 'mcdonalds_ordering_system'); //selecting database


    ?>